var QuoteView = require('./views/quoteView');

var app = function(){
  
}


window.onload = app;