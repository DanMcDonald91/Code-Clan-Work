import React from 'react';

class CountrySelector extends React.Component {
  render() {
    return (
      <select id="countries">
        <option>Country Selector</option>
      </select>
    );
  }
}

module.exports = CountrySelector;