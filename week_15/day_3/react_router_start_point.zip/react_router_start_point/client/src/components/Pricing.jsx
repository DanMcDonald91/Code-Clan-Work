import React from 'react'

const Pricing = () => (
  <div>
    <h4>Pricing</h4>
    <p>£££££££</p>
  </div>
)

export default Pricing
