class Motorbike extends Vehicle {
  public Motorbike(){
    
  }
}