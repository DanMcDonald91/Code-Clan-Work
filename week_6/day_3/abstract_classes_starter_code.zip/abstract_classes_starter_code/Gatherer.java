public interface Gatherer {
  String gatherFood();
}