public class PolarBear implements Gatherer {
  
  public String gatherFood(){
    return "Gone fishing";
  }
  
}