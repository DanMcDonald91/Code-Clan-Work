public class PolarBear extends Bear {
  
  public void gatherFood(){
    System.out.println("Gone fishing");
  }
  
}