package wizard_management;

public class Rug extends Carpet {

  public Rug(String colour){
    super(colour);
  }

}