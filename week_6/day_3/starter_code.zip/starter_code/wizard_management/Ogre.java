package wizard_management;

public class Ogre extends MythicalBeast {
  
  public Ogre(String name){
    super(name);
  }

}