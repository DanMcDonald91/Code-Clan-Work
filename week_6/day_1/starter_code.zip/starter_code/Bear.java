public class Bear{
  private String name;
  public Bear(String name){
    this.name = name;
  }
  public String getName(){
    return this.name;
  }
}
