public class Salmon {
  
  public String swim(){
   return "swimming";
  }

}