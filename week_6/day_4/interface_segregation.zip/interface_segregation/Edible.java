public interface Edible{
  
}