public class Honey implements Edible{
  
}