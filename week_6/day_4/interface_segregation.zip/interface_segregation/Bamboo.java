public class Bamboo implements Edible{
  
}