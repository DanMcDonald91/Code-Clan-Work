public class Salmon{
  
}