var app = function(){
  
}

window.onload = app;
